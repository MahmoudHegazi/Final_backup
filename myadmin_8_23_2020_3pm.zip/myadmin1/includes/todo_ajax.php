

<?php

if (isset($_GET['que'])) {
	 $task_id = $_GET['que'];
echo json_encode(array('success' => 1));

}
// get the q parameter from URL
/*
if ($_GET['done']) {


} else {
echo json_encode(array('success' => 0));	
}

*/
?>
